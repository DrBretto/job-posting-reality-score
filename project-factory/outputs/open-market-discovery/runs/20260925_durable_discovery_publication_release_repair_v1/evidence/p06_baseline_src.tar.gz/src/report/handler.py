"""Deterministic daily report renderer (markdown + json).

Guarantees carried forward from V1:
  - Never-fake vocabulary guard: system-authored language is scanned for banned tokens as whole
    words; provider-supplied strings are redacted before scanning because they are evidence labels,
    not system claims.
  - Every reported change cites evidence_refs (snapshot_id / event_id).
  - 100% deterministic, slot-filled from stored evidence. The narrator is never invoked.

Three things this version repairs, all named in the September 24 plan:

1. HEALTH WAS ONE AXIS AND ONE OF ITS BRANCHES WAS DEAD.
   `compute_run_health` computed `material` and then returned `VERIFIED_QUIET` on *both* sides of its
   own conditional, so the variable did nothing. Worse, fifteen successful configured fetches read as
   an all-clear. Health is now four independent axes — collection, discovery coverage, freshness,
   interpretation — and no axis is permitted to phrase itself as market coverage.

2. CANDIDATES WERE HIDDEN IN JSON.
   A 20-row cap ended with "N additional matching roles are retained in JSON", which is not a human
   handoff. The digest keeps a short highlights section AND the same document now carries the
   complete readable list: every retained credible role, with a direct link and a reason.

3. EMPLOYER WAS A PROPERTY OF THE SOURCE.
   A hardcoded fifteen-entry `_COMPANY_LABELS` map translated board tokens into company names. That
   map is gone: the employer comes off the job, which is what lets a posting from an employer nobody
   has named yet render correctly.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone

from src.common.models import (
    Band,
    CanonicalJob,
    ChangeEvent,
    ChangeEventType,
    DimensionScorecard,
    HistoryStatus,
    RunHealth,
    ScreenOutcome,
    SnapshotStatus,
    SourceKind,
    VerificationState,
)
from src.scoring.scoring import ScoreContext, ScoringProfile, score_job

# whole-word banned vocabulary (word boundaries so "Reality"/"really"/"already" are safe)
BANNED_TOKENS = ("fake", "real", "ghost", "scam", "fraud", "fraudulent", "lying", "fabricated")
_BANNED_RE = re.compile(r"\b(" + "|".join(BANNED_TOKENS) + r")\b", re.IGNORECASE)


class NeverFakeViolation(ValueError):
    """Raised when report output contains banned fake/real vocabulary."""


def assert_no_banned_vocab(text: str) -> None:
    m = _BANNED_RE.search(text)
    if m:
        raise NeverFakeViolation(
            f"banned vocabulary in report output: {m.group(0)!r} at pos {m.start()} "
            "(the system expresses behavior + confidence, never fake/real accusations)"
        )


# behavioral, confidence-bounded phrasing per change type (never an accusation)
_CHANGE_PHRASE = {
    ChangeEventType.FIRST_SEEN: "first observed",
    ChangeEventType.NO_MATERIAL_CHANGE: "no material change",
    ChangeEventType.MATERIALLY_CHANGED: "posting content edited",
    ChangeEventType.LOCATION_CHANGED: "location edited",
    ChangeEventType.SALARY_CHANGED: "compensation edited",
    ChangeEventType.REMOTE_HYBRID_LANGUAGE_CHANGED: "work-mode language edited",
    ChangeEventType.DISAPPEARED: "no longer listed",
    ChangeEventType.RETURNED: "listed again after an absence",
    ChangeEventType.PROBABLE_REPOST: "likely the same role reposted",
    ChangeEventType.SOURCE_FETCH_FAILED: "source fetch failed (collectors did not complete)",
    ChangeEventType.SOURCE_RESPONSE_PARTIAL: "source response partial (removals suppressed)",
    ChangeEventType.SOURCE_SUSPECT: "source coverage is in question (removals suppressed)",
    ChangeEventType.SOURCE_SEGMENT_CLOSED: "a department segment was confirmed closed",
    ChangeEventType.SOURCE_DISCOVERY_PARTIAL: "discovery covered part of its query plan",
}

_JOB_SCOPED = {
    ChangeEventType.FIRST_SEEN, ChangeEventType.MATERIALLY_CHANGED, ChangeEventType.LOCATION_CHANGED,
    ChangeEventType.SALARY_CHANGED, ChangeEventType.REMOTE_HYBRID_LANGUAGE_CHANGED,
    ChangeEventType.DISAPPEARED, ChangeEventType.RETURNED, ChangeEventType.PROBABLE_REPOST,
}
_MATERIAL = _JOB_SCOPED - {ChangeEventType.FIRST_SEEN}  # material for the quiet/changed decision
_SOURCE_SCOPED = {
    ChangeEventType.SOURCE_FETCH_FAILED, ChangeEventType.SOURCE_RESPONSE_PARTIAL,
    ChangeEventType.SOURCE_SUSPECT, ChangeEventType.SOURCE_SEGMENT_CLOSED,
    ChangeEventType.SOURCE_DISCOVERY_PARTIAL,
}
# Highlights cap for the digest's short section ONLY. It never hides a candidate: the complete
# readable list below it is uncapped.
_MAX_HIGHLIGHTS = 20
_MAX_EVENT_ITEMS = 15


# Documented provider lag, so a feed's publication date is never presented as the employer's own.
# Remotive's legal notice states its feed is delayed 24 hours.
SOURCE_LAG_HOURS: dict[str, int] = {"remotive": 24}
# Adzuna's query uses max_days_old=30, so its rows can be up to a month old by construction.
SOURCE_LOOKBACK_DAYS: dict[str, int] = {"adzuna": 30}

FRESH_WINDOW_HOURS = 24


def _aware(value: datetime | None) -> datetime | None:
    """Coerce a possibly-naive stored datetime to UTC.

    Defensive: a record written before `_iso` normalized zones would otherwise make the whole report
    raise rather than render.
    """
    if value is None:
        return None
    return value if value.tzinfo is not None else value.replace(tzinfo=timezone.utc)


def age_label(
    *,
    provider_published_at: datetime | None,
    provider_updated_at: datetime | None,
    first_seen_at: datetime | None,
    now: datetime,
    source_lag_hours: int | None = None,
) -> str:
    """Human age, naming WHICH date it rests on and never inventing one.

    The four dates are not synonyms (plan §3). A feed publication date is the provider's, not
    necessarily the employer's, so stated lag travels with it. With no date at all the answer is
    "unknown", qualified by when JPRS first saw it — not a guess.
    """
    now = _aware(now)
    provider_published_at = _aware(provider_published_at)
    provider_updated_at = _aware(provider_updated_at)
    first_seen_at = _aware(first_seen_at)

    def hours(then: datetime) -> float:
        return max(0.0, (now - then).total_seconds() / 3600.0)

    if provider_published_at is not None:
        age = hours(provider_published_at)
        label = f"published {_humanize(age)} ago (provider date)"
        if source_lag_hours:
            label += f"; provider publishes on a {source_lag_hours}h delay, so the employer's own date may be earlier"
        return label
    if provider_updated_at is not None:
        return (
            f"no publication date; employer last edited it {_humanize(hours(provider_updated_at))} "
            "ago (an edit is not a new posting)"
        )
    if first_seen_at is not None:
        return (
            f"age unknown — the source published no date; first seen by JPRS "
            f"{_humanize(hours(first_seen_at))} ago, which is a floor on its age, not its age"
        )
    return "age unknown and never observed"


def _humanize(hours_value: float) -> str:
    if hours_value < 1:
        return "under an hour"
    if hours_value < 48:
        return f"{int(round(hours_value))}h"
    return f"{int(hours_value // 24)}d"


def _report_dt_of(key: str) -> str:
    """The `dt=` partition a report key belongs to, or "" when the key is not partitioned."""
    for part in key.split("/"):
        if part.startswith("dt="):
            return part[3:]
    return ""


@dataclass
class RunTiming:
    """When this round actually looked, and when the last round that reported actually finished.

    Both come from durable artifacts other stages already write, never from the wall clock and never
    from the calendar day. The end of the UTC calendar day — which this module used before — made a
    07:05 posting look like it arrived seventeen hours in the future, and made every "since the
    previous round" comparison impossible because there was no previous boundary to compare against.
    """

    run_started_at: datetime | None = None
    previous_run_at: datetime | None = None
    previous_run_id: str | None = None
    basis: str = "unknown"
    cold_start_run: bool = False
    # The job ids the previous round's report actually showed. This, not a timestamp comparison, is
    # what "new since the last round" means: a posting Brett has not been shown yet. Identity needs
    # no clock, so it cannot be skewed by a replay, a late report, or two stages on different clocks.
    previously_reported_ids: frozenset[str] = frozenset()

    def to_json(self) -> dict:
        return {
            "run_started_at": self.run_started_at.isoformat() if self.run_started_at else None,
            "previous_run_at": self.previous_run_at.isoformat() if self.previous_run_at else None,
            "previous_run_id": self.previous_run_id,
            "basis": self.basis,
            "cold_start_run": self.cold_start_run,
            "previously_reported_count": len(self.previously_reported_ids),
            # Which mechanism decided "new since the last round". `reported-ids` is exact; the
            # timestamp fallback applies only when a previous report exists but listed no rows.
            "boundary": "reported-ids" if self.previously_reported_ids else (
                "timestamp" if self.previous_run_at else "cold-start"),
        }


def resolve_run_timing(s3, bucket: str, run_id: str, dt: str, *, now: datetime | None = None) -> RunTiming:
    """Read this round's start and the previous reported round's finish out of S3.

    `run_started_at` is the RUN_OPEN manifest's `opened_at`, written by ENUMERATE before any
    collection — the earliest truthful mark of "this round started looking".

    `previous_run_at` is the `report_generated_at` of the most recent EARLIER persisted report. A
    persisted report is itself the evidence that the round got as far as reporting, so a round that
    failed leaves none and is skipped rather than being credited with an observation it never made.
    Using the previous report's generation time, not its start, means a posting first seen partway
    through that round is not re-announced the next morning.

    The current run's own report is excluded, so a retry compares against the previous round instead
    of against its own first attempt and reporting zero new arrivals.
    """
    from src.common import s3layout

    manifest = _load_json(s3, bucket, s3layout.run_manifest_key(run_id), default=None) or {}
    started = _parse_datetime(manifest.get("opened_at")) if manifest.get("opened_at") else None
    basis = "manifest.opened_at"
    if started is None:
        # No manifest: the report still has a real invocation time, and saying so is better than
        # inventing a start or falling back to the end of the calendar day.
        started = _aware(now) or datetime.now(timezone.utc)
        basis = "report_invocation_time (RUN_OPEN manifest absent)"

    # Which reports are EARLIER is decided by the round they belong to (the dt in the key), and the
    # boundary VALUE is that round's finish. Ordering by the stored wall-clock stamp instead would
    # break on any replay of an earlier day, and would compare two different clocks.
    previous_at: datetime | None = None
    previous_id: str | None = None
    reported_ids: frozenset[str] = frozenset()
    candidates = sorted(
        (key for key in _list_keys(s3, bucket, "reports/") if key.endswith("report.json")),
        key=_report_dt_of, reverse=True,
    )
    for key in candidates:
        key_dt = _report_dt_of(key)
        if key_dt and key_dt >= dt:
            # Not an earlier round. This is also what stops a RETRY of this round from reading its
            # own first attempt as "the previous round" and reporting nothing new.
            continue
        prior = _load_json(s3, bucket, key, default=None) or {}
        # The previous round's FINISH, not its start: a posting first seen partway through that
        # round was already in its report and must not be re-announced the next morning.
        generated = prior.get("report_generated_at")
        stamp = _parse_datetime(generated) if generated else None
        if stamp is None:
            # A report written by an earlier release, before this field existed. Its run start is the
            # best durable mark it carries; it is earlier than its finish, so freshness errs toward
            # showing a row rather than hiding one.
            legacy = (prior.get("timing") or {}).get("run_started_at")
            stamp = _parse_datetime(legacy) if legacy else None
        ids = frozenset(
            row.get("job_id") for row in prior.get("complete_candidate_list", [])
            if row.get("job_id")
        )
        if stamp is None and not ids:
            # Nothing usable in this report at all: keep looking further back.
            continue
        # The id list is taken even when no timestamp could be read. Identity needs no clock, so a
        # report from the previous release still answers "has Brett seen this posting" exactly — and
        # the first round after a deploy is the one case where that matters most.
        previous_at, previous_id = (_aware(stamp) if stamp else None,
                                    prior.get("run_id") or key_dt or key)
        reported_ids = ids
        break

    return RunTiming(
        run_started_at=_aware(started),
        previous_run_at=previous_at,
        previous_run_id=previous_id,
        basis=basis,
        cold_start_run=previous_id is None,
        previously_reported_ids=reported_ids,
    )


def cold_start_sources(
    jobs: list[CanonicalJob],
    observations: dict[str, int] | None = None,
) -> set[str]:
    """Sources where `first_seen_at` carries no freshness information.

    On a source's FIRST successful observation every posting shares one `first_seen_at`: they did not
    all arrive since the last round, we simply started watching. Counting them as fresh arrivals
    would overstate freshness on the very first run.

    `observations` is the source's real success history from `current/state`. It is what decides,
    because timestamp cardinality alone cannot: a warm source that happens to carry ONE posting also
    has one distinct stamp, and reading that as a cold start suppressed a genuinely new arrival at
    every single-opening source. Cardinality is used only for a source with no history recorded.
    """
    seen: dict[str, set] = {}
    for job in jobs:
        seen.setdefault(job.source_id, set()).add(job.first_seen_at)
    cold: set[str] = set()
    for source, stamps in seen.items():
        count = (observations or {}).get(source)
        if count is not None:
            # Authoritative: one recorded successful observation means this is the first look.
            if count <= 1:
                cold.add(source)
            continue
        if len(stamps) <= 1:
            cold.add(source)
    return cold


def is_fresh_arrival(
    job: CanonicalJob,
    *,
    now: datetime,
    previous_run_at: datetime | None,
    cold_start: frozenset[str] | set[str] = frozenset(),
    previously_reported: frozenset[str] | set[str] | None = None,
) -> bool:
    """True when this posting is newly available to act on.

    Two independent ways to qualify, because either alone would miss cases:
      - the provider says it was published inside the fresh window, or
      - the previous round's report did not show it AND the observation is informative
        (see `cold_start_sources`). When no previous report is available, when JPRS first observed
        it falls back in as the weaker signal.
    Freshness NEVER excludes anything; it only decides which section a row is highlighted in.
    """
    now = _aware(now)
    published = _aware(job.provider_published_at)
    first_seen = _aware(job.first_seen_at)
    previous_run_at = _aware(previous_run_at)
    if published is not None:
        if (now - published).total_seconds() <= FRESH_WINDOW_HOURS * 3600:
            return True
    if job.source_id in cold_start:
        # First run for this source: first-seen tells us when WE started looking, not when the
        # employer posted. Publication date above is the only admissible evidence.
        return False
    if previously_reported is not None:
        # The previous round's report is on hand, so "new" is exact: Brett has not been shown this
        # posting. No clock arithmetic, so a weekend gap, a failed round, a retry and a replay all
        # give the same answer, and a posting first seen partway through the previous round — which
        # that report already showed — does not come back as new.
        return job.job_id not in previously_reported
    if previous_run_at is not None and first_seen is not None:
        # No previous report to compare against: fall back to when we first saw it.
        if first_seen >= previous_run_at:
            return True
    return False


# --------------------------------------------------------------------------------------------------
# Inputs
# --------------------------------------------------------------------------------------------------
@dataclass
class CoverageInput:
    """What discovery actually covered. Deliberately shaped to state what it did NOT cover."""

    discovery_attempted: list[str] = field(default_factory=list)
    discovery_succeeded: list[str] = field(default_factory=list)
    query_families_total: int = 0
    query_families_covered: int = 0
    query_families_saturated: list[str] = field(default_factory=list)
    query_families_deferred: list[str] = field(default_factory=list)
    query_families_never_run: list[str] = field(default_factory=list)
    backlog_items: int = 0
    backlog_reason: str | None = None
    budgets: dict = field(default_factory=dict)
    # Sources implemented but not runnable because a credential is absent. Named, not hidden.
    credential_gated: list[dict] = field(default_factory=list)
    inaccessible: list[dict] = field(default_factory=list)
    attributions: list[str] = field(default_factory=list)
    previously_unseen_employers: list[str] = field(default_factory=list)
    admission_summary: dict = field(default_factory=dict)
    policy_projection_note: str | None = None


@dataclass
class ReportInput:
    run_id: str
    dt: str
    expected_sources: list[str] = field(default_factory=list)
    succeeded_sources: list[str] = field(default_factory=list)  # SUCCESS-sentinel sources
    manifest_present: bool = True
    events: list[ChangeEvent] = field(default_factory=list)
    scorecards: list[DimensionScorecard] = field(default_factory=list)
    jobs: list[CanonicalJob] = field(default_factory=list)
    source_labels: dict[str, str] = field(default_factory=dict)
    # --- open-market additions (all optional so the monitoring-only path is unchanged) -----------
    screen_results: dict = field(default_factory=dict)   # job_id -> ScreenResult
    history_status: dict = field(default_factory=dict)   # job_id -> (HistoryStatus, note|None)
    coverage: CoverageInput | None = None
    dedup: dict = field(default_factory=dict)
    # Run timing, for the fresh-first cohort. Optional: without them the report simply has no
    # "since the last round" boundary and falls back to the provider publication window.
    run_started_at: datetime | None = None
    previous_run_at: datetime | None = None
    # source_id -> count of recorded successful observations, from current/state. Decides cold start.
    source_observations: dict[str, int] = field(default_factory=dict)
    # Job ids the previous round's report showed; None when there is no previous report to read.
    previously_reported_ids: frozenset[str] | None = None
    timing: dict = field(default_factory=dict)


# --------------------------------------------------------------------------------------------------
# Health: four axes, none of which may claim market coverage
# --------------------------------------------------------------------------------------------------
@dataclass
class HealthAxes:
    collection: RunHealth
    collection_missing: list[str]
    discovery: str
    discovery_detail: str
    freshness: str
    interpretation: str
    interpretation_detail: str

    def to_json(self) -> dict:
        return {
            "collection": self.collection.value,
            "collection_missing_sources": self.collection_missing,
            "discovery_coverage": self.discovery,
            "discovery_coverage_detail": self.discovery_detail,
            "freshness": self.freshness,
            "interpretation": self.interpretation,
            "interpretation_detail": self.interpretation_detail,
        }


def compute_run_health(inp: ReportInput) -> tuple[RunHealth, list[str]]:
    """Collection health only: did every EXPECTED source produce a SUCCESS sentinel?

    Unchanged contract for the monitoring path, with the dead branch removed. `material` used to be
    computed here and then discarded by a conditional whose arms were identical; whether anything
    changed is a separate question from whether collection completed, and it is answered by the
    freshness axis instead of being folded into this one.
    """
    if not inp.manifest_present:
        return RunHealth.NO_RUN, list(inp.expected_sources)
    missing = sorted(set(inp.expected_sources) - set(inp.succeeded_sources))
    if missing:
        return RunHealth.INCOMPLETE, missing
    return RunHealth.VERIFIED_QUIET, missing


def compute_health_axes(inp: ReportInput) -> HealthAxes:
    collection, missing = compute_run_health(inp)
    cov = inp.coverage

    # --- discovery coverage -----------------------------------------------------------------------
    if cov is None or not cov.discovery_attempted:
        discovery = "NOT-RUN"
        discovery_detail = (
            "no employer-independent discovery ran in this report; the results below describe the "
            "configured employers that were monitored, which is not a search of the open market"
        )
    else:
        failed = sorted(set(cov.discovery_attempted) - set(cov.discovery_succeeded))
        incomplete = bool(
            failed or cov.backlog_items or cov.query_families_deferred
            or cov.query_families_never_run or cov.query_families_saturated
            or cov.credential_gated
        )
        discovery = "PARTIAL" if incomplete else "PLAN-COVERED"
        bits = [
            f"{len(cov.discovery_succeeded)}/{len(cov.discovery_attempted)} discovery sources "
            f"returned results",
            f"{cov.query_families_covered}/{cov.query_families_total} query families covered",
        ]
        if failed:
            bits.append(f"failed: {', '.join(failed)}")
        if cov.query_families_saturated:
            bits.append(
                f"hit a result ceiling (more may exist): {', '.join(cov.query_families_saturated)}"
            )
        if cov.query_families_deferred:
            bits.append(f"deferred to a later run: {', '.join(cov.query_families_deferred)}")
        if cov.query_families_never_run:
            bits.append(f"never run yet: {', '.join(cov.query_families_never_run)}")
        if cov.backlog_items:
            bits.append(f"{cov.backlog_items} query items queued and resumable")
        if cov.credential_gated:
            bits.append(
                "not runnable without a credential: "
                + ", ".join(sorted(g.get("provider", "?") for g in cov.credential_gated))
            )
        discovery_detail = "; ".join(bits)

    # --- freshness --------------------------------------------------------------------------------
    material = [e for e in inp.events if e.event_type in _MATERIAL]
    first_seen = [e for e in inp.events if e.event_type == ChangeEventType.FIRST_SEEN]
    if first_seen or material:
        freshness = "CHANGED"
    else:
        freshness = "NO-CHANGE-OBSERVED"

    # --- interpretation health --------------------------------------------------------------------
    suspect = [e for e in inp.events if e.event_type == ChangeEventType.SOURCE_SUSPECT]
    partial = [e for e in inp.events if e.event_type == ChangeEventType.SOURCE_RESPONSE_PARTIAL]
    failed_fetch = [e for e in inp.events if e.event_type == ChangeEventType.SOURCE_FETCH_FAILED]
    closed = [e for e in inp.events if e.event_type == ChangeEventType.SOURCE_SEGMENT_CLOSED]
    leads = sum(
        1 for j in inp.jobs if j.verification_state == VerificationState.UNVERIFIED_LEAD
    )
    if suspect or partial or failed_fetch:
        interpretation = "DEGRADED"
        parts = []
        if failed_fetch:
            parts.append(f"{len(failed_fetch)} source(s) could not be downloaded")
        if partial:
            parts.append(f"{len(partial)} source(s) returned an incomplete response")
        if suspect:
            parts.append(
                f"{len(suspect)} source(s) have coverage in question, so their removals are held"
            )
        interpretation_detail = "; ".join(parts)
    else:
        interpretation = "CLEAN"
        interpretation_detail = "no source-level condition is suppressing removals"
    if closed:
        interpretation_detail += (
            f"; {len(closed)} previously-held department segment(s) were confirmed closed and "
            "released this run"
        )
    if leads:
        interpretation_detail += (
            f"; {leads} posting(s) are aggregator leads whose employer posting has not been "
            "confirmed directly"
        )

    return HealthAxes(
        collection=collection,
        collection_missing=missing,
        discovery=discovery,
        discovery_detail=discovery_detail,
        freshness=freshness,
        interpretation=interpretation,
        interpretation_detail=interpretation_detail,
    )


# --------------------------------------------------------------------------------------------------
# rendering helpers
# --------------------------------------------------------------------------------------------------
def _evidence_str(e: ChangeEvent) -> str:
    return f"[snapshot={e.snapshot_id}, event={e.event_id}]"


def _employer(job: CanonicalJob, source_labels: dict[str, str]) -> str:
    """Employer for display, from the JOB.

    The former hardcoded company-label table is deliberately gone. The registry's operator-curated
    slug is still honored as a fallback for a board source that did not state a company name.
    """
    if job.employer_name:
        return job.employer_name
    slug = source_labels.get(job.source_id) or job.source_id.partition(":")[2] or job.source_id
    return slug.replace("-", " ").replace("_", " ").strip().title()


def _source_employer(source_id: str, source_labels: dict[str, str]) -> str:
    slug = source_labels.get(source_id) or source_id.partition(":")[2] or source_id
    return slug.replace("-", " ").replace("_", " ").strip().title()


def _md_text(value: str) -> str:
    return value.replace("\\", "\\\\").replace("[", "\\[").replace("]", "\\]").replace("|", "\\|")


def _job_link(job: CanonicalJob) -> str:
    title = _md_text(job.title)
    url = job.posting_url or job.apply_url or ""
    return f"[{title}]({url})" if url else title


def _screen(inp: ReportInput, job_id: str):
    return inp.screen_results.get(job_id)


def _history(inp: ReportInput, job_id: str) -> tuple[HistoryStatus, str | None]:
    entry = inp.history_status.get(job_id)
    if entry is None:
        return HistoryStatus.NEW, None
    if isinstance(entry, tuple):
        return entry
    return entry, None


def _ranked(inp: ReportInput) -> list[DimensionScorecard]:
    """Every credible card, ranked. Screening EXCLUDED cards are handled in their own section."""
    eligible = [
        card for card in inp.scorecards
        if not card.excluded and card.brett_fit.band in (Band.HIGH, Band.MEDIUM)
    ]
    return sorted(
        eligible,
        key=lambda card: (
            -(card.application_priority.score if card.application_priority.score is not None else -1.0),
            -(card.brett_fit.score if card.brett_fit.score is not None else -1.0),
            card.job_id,
        ),
    )


def _signal_summary(card: DimensionScorecard) -> str:
    detail = card.brett_fit.detail
    signals: list[str] = []
    for key in ("title_signals", "skill_signals"):
        signals.extend(s for s in str(detail.get(key, "")).split(",") if s)
    return ", ".join(signals[:6])


def _why_fit(card: DimensionScorecard) -> str:
    """A short human reason, not a restatement of the number."""
    detail = card.brett_fit.detail
    signals = _signal_summary(card)
    path = str(detail.get("recall_path", ""))
    bits = []
    if signals:
        bits.append(f"matches on {signals}")
    if path == "work-evidence":
        bits.append("ordinary title, but the described work is in lane")
    elif path == "work-evidence-nontechnical-title":
        bits.append("title is outside the usual lane; kept for the work described")
    if detail.get("is_stretch_level"):
        bits.append("stretch level — judge the actual scope")
    geography = str(detail.get("geography", ""))
    if geography:
        bits.append(geography.replace("-", " "))
    return "; ".join(bits) or "scored on stored evidence"


def _gaps(inp: ReportInput, job: CanonicalJob, card: DimensionScorecard) -> str:
    """Important gaps and process checks — the half of the row that prevents wasted mornings."""
    bits: list[str] = []
    screen = _screen(inp, job.job_id)
    if screen is not None:
        for hit in screen.pending_checks:
            bits.append(hit.reason)
    if job.verification_state == VerificationState.UNVERIFIED_LEAD:
        bits.append("aggregator lead: confirm against the employer posting before preparing")
    if job.salary is None:
        bits.append("no published compensation")
    if job.identity_low_confidence:
        bits.append("posting identity is low confidence at this source")
    if card.application_priority.band == Band.UNKNOWN:
        bits.append("too few observations to assess hiring activity yet")
    return "; ".join(bits[:4])


def _dates(job: CanonicalJob) -> str:
    """Four distinct dates, never interchanged. An imported posting is not 'newly posted'."""
    parts = []
    if job.provider_published_at:
        parts.append(f"employer published {job.provider_published_at.date()}")
    if job.provider_updated_at:
        parts.append(f"employer updated {job.provider_updated_at.date()}")
    if job.first_seen_at:
        parts.append(f"first seen by JPRS {job.first_seen_at.date()}")
    if job.verified_at:
        parts.append(f"last verified {job.verified_at.date()}")
    return "; ".join(parts)


def _location(job: CanonicalJob) -> str:
    base = job.raw_location or job.canonical_location or "location not stated"
    if job.secondary_locations:
        base += f" (also: {', '.join(job.secondary_locations[:3])})"
    return base


def _comp(job: CanonicalJob) -> str:
    if job.salary is None:
        return "compensation not published"
    lo, hi = job.salary.min, job.salary.max
    if lo and hi:
        return f"{lo:,.0f}-{hi:,.0f} {job.salary.currency or ''}".strip()
    if lo or hi:
        return f"{(lo or hi):,.0f} {job.salary.currency or ''}".strip()
    return "compensation published without a stated range"


def _match_json(card: DimensionScorecard, job: CanonicalJob, inp: ReportInput) -> dict:
    screen = _screen(inp, job.job_id)
    status, note = _history(inp, job.job_id)
    return {
        "source_id": card.source_id,
        "job_id": card.job_id,
        "employer": _employer(job, inp.source_labels),
        "source_kind": job.source_kind.value,
        "discovery_query": job.discovery_query,
        "discovery_query_family": job.discovery_query_family,
        "title": job.title,
        "location": _location(job),
        "remote_mode": job.remote_hybrid_language.value,
        "employment_type": job.employment_type.value,
        "compensation": _comp(job),
        "posting_url": job.posting_url or job.apply_url or None,
        "apply_url": job.apply_url or job.posting_url or None,
        "verification_state": job.verification_state.value,
        "uncertainty": list(job.uncertainty),
        "provider_published_at": (
            job.provider_published_at.isoformat() if job.provider_published_at else None
        ),
        "provider_updated_at": (
            job.provider_updated_at.isoformat() if job.provider_updated_at else None
        ),
        "first_seen_at": job.first_seen_at.isoformat() if job.first_seen_at else None,
        "verified_at": job.verified_at.isoformat() if job.verified_at else None,
        "fit_score": card.brett_fit.score,
        "fit_band": card.brett_fit.band.value,
        "priority_score": card.application_priority.score,
        "priority_band": card.application_priority.band.value,
        "priority_confidence": card.application_priority.confidence,
        "recall_path": card.brett_fit.detail.get("recall_path"),
        "why_fit": _why_fit(card),
        "gaps_and_checks": _gaps(inp, job, card),
        "signals": _signal_summary(card),
        "screen_outcome": screen.outcome if screen is not None else None,
        "screen_detail": screen.to_json() if screen is not None else None,
        "age_label": _age_of(job, inp, inp.run_started_at
                             or datetime.fromisoformat(f"{inp.dt}T23:59:59+00:00")),
        "is_fresh_arrival": is_fresh_arrival(
            job,
            now=inp.run_started_at or datetime.fromisoformat(f"{inp.dt}T23:59:59+00:00"),
            previous_run_at=inp.previous_run_at,
            cold_start=cold_start_sources(inp.jobs, inp.source_observations),
            previously_reported=inp.previously_reported_ids,
        ),
        "first_observation_run_for_source": job.source_id in cold_start_sources(
            inp.jobs, inp.source_observations),
        "source_lag_hours": SOURCE_LAG_HOURS.get(job.source_id.partition(":")[0]),
        "source_lookback_days": SOURCE_LOOKBACK_DAYS.get(job.source_id.partition(":")[0]),
        "history_status": status.value if hasattr(status, "value") else str(status),
        "history_note": note,
        "provenance": [p.model_dump(mode="json") for p in job.provenance],
        "possible_duplicate_of": list(job.possible_duplicate_of),
    }


def _event_subject(event: ChangeEvent, jobs_by_id: dict[str, CanonicalJob], inp: ReportInput) -> str:
    job = jobs_by_id.get(event.job_id or "")
    if job is None:
        return str(event.job_id or event.source_id)
    return f"{_job_link(job)} at {_employer(job, inp.source_labels)}"


def _source_values(inp: ReportInput) -> list[str]:
    """Provider-supplied strings that may legitimately contain otherwise guarded vocabulary.

    Discovery widens this a lot: employer names, industries and screening evidence spans are all
    provider text now, and an employer legitimately named "Real Estate Partners" must not blow up
    the report.
    """
    from src.common.normalize import normalize_employer, normalize_title_for_matching

    values: set[str] = set(inp.source_labels.values()) | set(inp.expected_sources)
    for job in inp.jobs:
        values.update(filter(None, (
            job.source_id, job.job_id, job.title, job.raw_location, job.canonical_location,
            job.posting_url, job.apply_url, job.employer_name, job.employer_domain,
            job.employer_careers_url, job.industry, job.job_level, job.department, job.team,
            job.discovery_query, job.discovery_query_family, job.apply_host,
            # DERIVED forms of provider text are still provider text. The normalized title is
            # emitted in the scorecard detail, and a posting legitimately titled "Real-Time AI
            # Engineer" normalizes to a string the original title does not contain, so redacting
            # only the original let a sourced word reach the guard.
            normalize_title_for_matching(job.title),
            normalize_employer(job.employer_name),
        )))
        values.update(job.secondary_locations)
        values.update(job.uncertainty)
        for prov in job.provenance:
            values.update(filter(None, (prov.source_id, prov.job_id, prov.posting_url,
                                        prov.discovery_query)))
    for event in inp.events:
        values.update(filter(None, (
            event.source_id, event.job_id, event.event_id, event.snapshot_id,
            event.prior_snapshot_id, event.linked_job_id, event.content_hash,
        )))
    for screen in inp.screen_results.values():
        for bucket in (screen.exclusions, screen.pending_checks, screen.suppressed):
            for hit in bucket:
                if hit.matched_text:
                    values.add(hit.matched_text)
    cov = inp.coverage
    if cov is not None:
        values.update(cov.attributions)
        values.update(cov.previously_unseen_employers)
        for gated in cov.credential_gated:
            values.update(str(v) for v in gated.values() if v)
        for item in cov.inaccessible:
            values.update(str(v) for v in item.values() if v)
    values.update(_source_employer(s, inp.source_labels) for s in inp.expected_sources)
    return sorted((str(value) for value in values if value), key=len, reverse=True)


def _assert_report_language(markdown: str, report_json: dict, inp: ReportInput) -> None:
    markdown_guard = markdown
    json_guard = json.dumps(report_json, default=str)
    for value in _source_values(inp):
        markdown_guard = markdown_guard.replace(value, "<SOURCE_VALUE>")
        json_guard = json_guard.replace(value, "<SOURCE_VALUE>")
    assert_no_banned_vocab(markdown_guard)
    assert_no_banned_vocab(json_guard)


# --------------------------------------------------------------------------------------------------
# render
# --------------------------------------------------------------------------------------------------
def render_report(inp: ReportInput) -> tuple[str, dict]:
    """Return (markdown, json_dict). Deterministic; narrator NOT invoked."""
    axes = compute_health_axes(inp)
    health, missing = axes.collection, axes.collection_missing
    material_events = [e for e in inp.events if e.event_type in _MATERIAL]
    first_seen = [e for e in inp.events if e.event_type == ChangeEventType.FIRST_SEEN]
    source_events = [e for e in inp.events if e.event_type in _SOURCE_SCOPED]
    jobs_by_id = {job.job_id: job for job in inp.jobs}
    cov = inp.coverage

    ranked = _ranked(inp)
    pairs = [(card, jobs_by_id[card.job_id]) for card in ranked if card.job_id in jobs_by_id]
    report_now = inp.run_started_at or datetime.fromisoformat(f"{inp.dt}T23:59:59+00:00")
    cold_start = cold_start_sources(inp.jobs, inp.source_observations)

    # Partition by screening outcome and history. Nothing is dropped; every posting lands somewhere.
    strong: list[tuple] = []
    review: list[tuple] = []
    previously: list[tuple] = []
    for card, job in pairs:
        screen = _screen(inp, job.job_id)
        status, _note = _history(inp, job.job_id)
        if screen is not None and screen.outcome == ScreenOutcome.EXCLUDED.value:
            continue
        if status != HistoryStatus.NEW:
            previously.append((card, job))
        elif screen is not None and screen.outcome == ScreenOutcome.PENDING_CHECK.value:
            review.append((card, job))
        else:
            strong.append((card, job))

    excluded_rows = [
        (card, jobs_by_id[card.job_id]) for card in inp.scorecards
        if card.job_id in jobs_by_id
        and (_screen(inp, card.job_id) is not None)
        and _screen(inp, card.job_id).outcome == ScreenOutcome.EXCLUDED.value
    ]
    complete_list = strong + review + previously

    # FRESH-FIRST cohort. A highlight, not a filter and not a re-ranking of the complete list:
    # nothing is excluded for being old, and because the complete list below stays fit-ranked, a
    # fresh weak posting cannot outrank a strong one merely for being new.
    def _by_fit(pairs):
        """Fit-descending. Freshness selects the cohort; it never reorders within one."""
        return sorted(
            pairs,
            key=lambda cj: (
                -(cj[0].brett_fit.score if cj[0].brett_fit.score is not None else -1.0),
                cj[0].job_id,
            ),
        )

    fresh_pairs = _by_fit([
        (card, job) for card, job in complete_list
        if is_fresh_arrival(job, now=report_now, previous_run_at=inp.previous_run_at,
                            cold_start=cold_start,
                            previously_reported=inp.previously_reported_ids)
    ])
    fresh_ids = {card.job_id for card, _job in fresh_pairs}
    older_strong = _by_fit([
        (card, job) for card, job in complete_list
        if card.job_id not in fresh_ids
        and card.brett_fit.band in (Band.HIGH, Band.MEDIUM)
        and (card.brett_fit.score or 0) >= 0.45
    ])
    relevant_ids = {card.job_id for card, _ in pairs}
    relevance_order = {card.job_id: i for i, (card, _) in enumerate(pairs)}

    # ---- header ----
    if health == RunHealth.VERIFIED_QUIET:
        collection_line = (
            "every expected source produced a successful download"
            + ("; nothing material changed." if axes.freshness == "NO-CHANGE-OBSERVED"
               else "; changes are listed below.")
        )
    elif health == RunHealth.INCOMPLETE:
        collection_line = (
            "these sources lack a successful download: " + ", ".join(missing)
        )
    else:
        collection_line = "no manifest was opened for this run_id (missed-run watchdog)."

    lines = [
        f"# Job Posting Reality Score — daily report {inp.dt}",
        "",
        f"Run: {inp.run_id}  ·  scoring profile v{_profile_version(inp)}",
        f"Completeness: {len(set(inp.succeeded_sources) & set(inp.expected_sources))}/"
        f"{len(set(inp.expected_sources))} sources succeeded",
        "",
        "## Run health",
        "",
        f"- **Collection ({health.value})** — {collection_line}",
        f"- **Discovery coverage ({axes.discovery})** — {axes.discovery_detail}.",
        f"- **Freshness ({axes.freshness})** — "
        f"{len(first_seen)} newly observed, {len(material_events)} edited.",
        f"- **Interpretation ({axes.interpretation})** — {axes.interpretation_detail}.",
        "",
        "> Collection health describes the sources that were actually queried. It is not a "
        "statement about the job market: a complete download of every configured source still "
        "covers only those sources, and the discovery coverage line above is the one that says how "
        "wide the search itself reached.",
        "",
        f"Retained credible roles: {len(complete_list)} "
        f"({len(strong)} new, {len(review)} needing a check, {len(previously)} already in progress). "
        f"Policy exclusions: {len(excluded_rows)}. Postings considered: {len(inp.jobs)}.",
        "",
        # The central workflow states that "the initial JPRS score is not a final rejection gate" and
        # that promising overflow must be preserved "rather than padding the batch or silently
        # discarding opportunities". A count that appears nowhere is a silent discard, so the
        # below-threshold tail is stated here and remains addressable in the JSON.
        f"Below the fit threshold and therefore not listed above: "
        f"{_below_threshold_count(inp, complete_list, excluded_rows)}. These are retained with full "
        f"scores in `daily_report.json` and are not a judgment by the research step — ranking is a "
        f"triage aid, not a verdict.",
        "",
    ]

    if cov is not None and cov.policy_projection_note:
        lines += [f"Candidate policy: {cov.policy_projection_note}", ""]

    # ---- coverage and backlog ----
    if cov is not None:
        lines += ["## Coverage and backlog", ""]
        if cov.discovery_attempted:
            lines.append(
                f"- Discovery sources queried: {', '.join(sorted(cov.discovery_attempted))}"
            )
            failed = sorted(set(cov.discovery_attempted) - set(cov.discovery_succeeded))
            if failed:
                lines.append(f"- Discovery sources that returned nothing usable: {', '.join(failed)}")
        else:
            lines.append(
                "- No employer-independent discovery source ran; this report covers monitored "
                "employers only"
            )
        lines.append(
            f"- Query families: {cov.query_families_covered}/{cov.query_families_total} covered"
        )
        if cov.query_families_saturated:
            lines.append(
                f"- Hit a result ceiling, so more may exist behind it: "
                f"{', '.join(cov.query_families_saturated)}"
            )
        if cov.query_families_deferred:
            lines.append(
                f"- Deferred to a later run by the request budget, not discarded: "
                f"{', '.join(cov.query_families_deferred)}"
            )
        if cov.query_families_never_run:
            lines.append(f"- Never run yet: {', '.join(cov.query_families_never_run)}")
        if cov.backlog_items:
            lines.append(
                f"- Resumable backlog: {cov.backlog_items} query item(s)"
                + (f" — {cov.backlog_reason}" if cov.backlog_reason else "")
            )
        for gated in cov.credential_gated:
            lines.append(
                f"- **{gated.get('provider')} did not run**: {gated.get('reason')}. "
                f"Required setup: {gated.get('required')}"
            )
        for item in cov.inaccessible:
            lines.append(
                f"- Could not access {item.get('target')}: {item.get('reason')}"
            )
        if cov.previously_unseen_employers:
            shown = sorted(cov.previously_unseen_employers)
            lines.append(
                f"- Employers seen this run that were not in the monitored registry: "
                f"{len(shown)} ({', '.join(shown[:12])}"
                + (", …" if len(shown) > 12 else "") + ")"
            )
        if cov.budgets:
            spent = ", ".join(
                f"{p}: {b.get('requests_spent')}/{b.get('max_requests_per_run')}"
                for p, b in sorted(cov.budgets.items())
            )
            lines.append(f"- Request budgets used: {spent}")
        lines.append("")

    # ---- source notices ----
    if source_events:
        lines += ["## Source notices", ""]
        for e in sorted(source_events, key=lambda x: (x.source_id, x.event_type.value)):
            employer = _source_employer(e.source_id, inp.source_labels)
            note = f" {e.notes}" if e.notes else ""
            lines.append(
                f"- {employer} ({e.source_id}): {_CHANGE_PHRASE[e.event_type]}.{note} "
                f"{_evidence_str(e)}"
            )
        lines.append("")

    # ---- highlights ----
    if strong:
        lines += ["## New strong candidates", ""]
        for card, job in strong[:_MAX_HIGHLIGHTS]:
            lines.append(_row(card, job, inp))
        if len(strong) > _MAX_HIGHLIGHTS:
            lines.append(
                f"- The remaining {len(strong) - _MAX_HIGHLIGHTS} new candidate(s) are listed in "
                f"full in the complete list below — nothing is held back in JSON."
            )
        lines.append("")
    elif inp.scorecards:
        lines += [
            "## New strong candidates", "",
            "No new posting cleared the fit threshold in what was actually searched this run. "
            + (
                "Discovery coverage was partial, so this is not a statement that no such job "
                "exists." if axes.discovery != "PLAN-COVERED" else
                "The planned query set was covered, so this is a completed search with zero strong "
                "matches rather than an incomplete one."
            ),
            "",
        ]

    if fresh_pairs:
        lines += [
            "## New since the last round", "",
            f"{len(fresh_pairs)} credible role(s) that arrived since the previous check or were "
            f"published within {FRESH_WINDOW_HOURS}h. Applying early helps, so these come first — "
            f"but they are ordered by fit, and nothing below is excluded for being older."
            + (
                f" Note: {len(cold_start)} source(s) were observed for the first time this run, so "
                f"for those only a provider publication date counts as evidence of freshness."
                if cold_start else ""
            ),
            "",
        ]
        for card, job in fresh_pairs[:_MAX_HIGHLIGHTS]:
            lines.append(_row(card, job, inp) + f" | {_md_text(_age_of(job, inp, report_now))}")
        if len(fresh_pairs) > _MAX_HIGHLIGHTS:
            lines.append(
                f"- the remaining {len(fresh_pairs) - _MAX_HIGHLIGHTS} fresh role(s) appear in the "
                f"complete list below"
            )
        lines.append("")
    elif inp.scorecards:
        lines += [
            "## New since the last round", "",
            "Nothing credible arrived since the previous check. Older strong fits below are still "
            "worth the morning; this is not an empty day.",
            "",
        ]

    if older_strong:
        lines += [
            "## Older, still strong", "",
            "Retained because the fit is strong, not because they are new. Age is stated on each "
            "row; nothing here is excluded for being older than the fresh window.",
            "",
        ]
        for card, job in older_strong[:_MAX_HIGHLIGHTS]:
            lines.append(_row(card, job, inp) + f" | {_md_text(_age_of(job, inp, report_now))}")
        lines.append("")

    if review:
        lines += [
            "## Needs a check before preparing", "",
            "These are credible on the evidence available, but something specific is unconfirmed.",
            "",
        ]
        for card, job in review:
            lines.append(_row(card, job, inp))
        lines.append("")

    if previously:
        lines += [
            "## Already prepared, submitted, or set aside", "",
            "Surfaced separately so useful queued work stays visible without being announced as new.",
            "",
        ]
        for card, job in previously:
            status, note = _history(inp, job.job_id)
            suffix = f" — history: {status.value if hasattr(status, 'value') else status}"
            if note:
                suffix += f" ({note})"
            lines.append(_row(card, job, inp) + suffix)
        lines.append("")

    # ---- the complete readable list ----
    if complete_list:
        lines += [
            "## Complete candidate list", "",
            f"All {len(complete_list)} retained credible role(s), each with a direct link and a "
            f"reason. This is the full set — there is no hidden overflow.",
            "",
        ]
        for index, (card, job) in enumerate(complete_list, start=1):
            status, _n = _history(inp, job.job_id)
            screen = _screen(inp, job.job_id)
            lines.append(
                f"{index}. **{_md_text(_employer(job, inp.source_labels))}** — {_job_link(job)}  \n"
                f"   {_md_text(_location(job))} · {_md_text(_comp(job))} · "
                f"{job.employment_type.value} · via `{job.source_id}`"
                + (f" · query `{_md_text(job.discovery_query_family or '')}`"
                   if job.discovery_query_family else "")
                + "  \n"
                f"   fit {card.brett_fit.band.value} "
                f"{_fmt(card.brett_fit.score)} · priority {card.application_priority.band.value} "
                f"{_fmt(card.application_priority.score)} · "
                f"screen {screen.outcome if screen else 'not-screened'} · "
                f"history {status.value if hasattr(status, 'value') else status}  \n"
                f"   why: {_md_text(_why_fit(card))}  \n"
                + (f"   check: {_md_text(_gaps(inp, job, card))}  \n"
                   if _gaps(inp, job, card) else "")
                + (f"   dates: {_md_text(_dates(job))}  \n" if _dates(job) else "")
                + f"   age: {_md_text(_age_of(job, inp, report_now))}"
                + ("  ·  **new since the last round**" if card.job_id in fresh_ids else "")
                + "  \n"
                + (f"   also seen at: "
                   f"{_md_text(', '.join(sorted({p.source_id for p in job.provenance})))}  \n"
                   if len(job.provenance) > 1 else "")
                + (f"   possibly the same posting as: "
                   f"{_md_text(', '.join(job.possible_duplicate_of[:3]))}  \n"
                   if job.possible_duplicate_of else "")
            )
        lines.append("")

    # ---- exclusions with reasons ----
    if excluded_rows:
        lines += ["## Excluded by candidate policy", "",
                  "Grouped by rule, with the text that triggered each one.", ""]
        by_rule: dict[str, list] = {}
        for card, job in excluded_rows:
            screen = _screen(inp, job.job_id)
            for hit in screen.exclusions:
                by_rule.setdefault(hit.rule_id, []).append((job, hit))
        for rule_id in sorted(by_rule):
            lines.append(f"**{rule_id}**")
            for job, hit in by_rule[rule_id][:_MAX_EVENT_ITEMS]:
                lines.append(
                    f"- {_md_text(_employer(job, inp.source_labels))} — {_job_link(job)}: "
                    f"{_md_text(hit.reason)}"
                )
            if len(by_rule[rule_id]) > _MAX_EVENT_ITEMS:
                lines.append(
                    f"- and {len(by_rule[rule_id]) - _MAX_EVENT_ITEMS} more under this rule "
                    f"(all in JSON)"
                )
            lines.append("")

    # ---- changes / newly observed ----
    visible_material = (
        [e for e in material_events if e.job_id in relevant_ids] if inp.scorecards
        else material_events
    )
    visible_first_seen = (
        [e for e in first_seen if e.job_id in relevant_ids] if inp.scorecards else first_seen
    )
    if visible_material:
        lines += ["## Changes", ""]
        ordered = sorted(
            visible_material,
            key=lambda x: (relevance_order.get(x.job_id or "", len(relevance_order)),
                           x.event_type.value),
        )
        for e in ordered[:_MAX_EVENT_ITEMS]:
            extra = ""
            if e.event_type == ChangeEventType.PROBABLE_REPOST and e.repost_score is not None:
                extra = f" (confidence {e.repost_score}; linked {e.linked_job_id})"
            lines.append(
                f"- {_event_subject(e, jobs_by_id, inp)}: {_CHANGE_PHRASE[e.event_type]}{extra} "
                f"{_evidence_str(e)}"
            )
        if len(visible_material) > _MAX_EVENT_ITEMS:
            lines.append(
                f"- {len(visible_material) - _MAX_EVENT_ITEMS} further change(s) are in JSON."
            )
        lines.append("")

    if visible_first_seen:
        lines += ["## Newly observed postings", ""]
        ordered = sorted(
            visible_first_seen,
            key=lambda x: relevance_order.get(x.job_id or "", len(relevance_order)),
        )
        for e in ordered[:_MAX_EVENT_ITEMS]:
            lines.append(
                f"- {_event_subject(e, jobs_by_id, inp)}: {_CHANGE_PHRASE[e.event_type]} "
                f"{_evidence_str(e)}"
            )
        if len(visible_first_seen) > _MAX_EVENT_ITEMS:
            lines.append(
                f"- {len(visible_first_seen) - _MAX_EVENT_ITEMS} further new posting(s) are in JSON."
            )
        lines.append("")

    # ---- dedup + admission + attribution ----
    if inp.dedup:
        lines += [
            "## Duplicates and distinct requisitions", "",
            f"- Merged as the same posting seen more than once: "
            f"{inp.dedup.get('hard_merges', 0)}",
            f"- Cross-linked as possibly the same, both kept for review: "
            f"{inp.dedup.get('soft_possible_duplicate_links', 0)}",
            f"- Deliberately NOT merged because they are distinct openings: "
            f"{inp.dedup.get('links_blocked_as_distinct_requisitions', 0)}",
            "",
        ]
    if cov is not None and cov.admission_summary:
        lines += ["## Newly discovered sources", ""]
        for state, employers in sorted(cov.admission_summary.get("by_state", {}).items()):
            lines.append(f"- {state}: {len(employers)} ({', '.join(employers[:8])}"
                         + (", …" if len(employers) > 8 else "") + ")")
        lines.append("")
    if cov is not None and cov.attributions:
        lines += ["## Source attribution", ""]
        for attribution in sorted(set(cov.attributions)):
            lines.append(f"- {attribution}")
        lines.append("")

    markdown = "\n".join(lines)

    report_json = {
        "run_id": inp.run_id,
        "dt": inp.dt,
        # Written so the NEXT round has a durable previous-observation boundary to compare against.
        # A persisted report is the evidence that this round reported; a failed round writes none.
        "report_generated_at": datetime.now(timezone.utc).isoformat(),
        "timing": inp.timing or {
            "run_started_at": inp.run_started_at.isoformat() if inp.run_started_at else None,
            "previous_run_at": inp.previous_run_at.isoformat() if inp.previous_run_at else None,
            "basis": "supplied_directly",
            "cold_start_run": inp.previous_run_at is None,
        },
        "run_health": health.value,
        "health_axes": axes.to_json(),
        "header": collection_line,
        "expected_sources": sorted(inp.expected_sources),
        "succeeded_sources": sorted(inp.succeeded_sources),
        "incomplete_sources": missing,
        "completeness_ratio": _ratio(inp),
        "current_job_count": len(inp.jobs),
        "matching_job_count": len(complete_list),
        "new_strong_count": len(strong),
        "fresh_arrival_count": len(fresh_pairs),
        "older_strong_count": len(older_strong),
        "fresh_window_hours": FRESH_WINDOW_HOURS,
        "needs_check_count": len(review),
        "previously_engaged_count": len(previously),
        "policy_excluded_count": len(excluded_rows),
        "below_fit_threshold_count": _below_threshold_count(inp, complete_list, excluded_rows),
        "complete_candidate_list": [_match_json(c, j, inp) for c, j in complete_list],
        # `top_matches` keeps its original meaning — the ranked best retained candidates — so an
        # existing consumer of the JSON is unaffected. The new three-way split (new / needs-a-check /
        # already in progress) is reported alongside it rather than by redefining this key.
        "top_matches": [_match_json(c, j, inp) for c, j in complete_list[:_MAX_HIGHLIGHTS]],
        "policy_exclusions": [_match_json(c, j, inp) for c, j in excluded_rows],
        "coverage": (
            {
                "discovery_attempted": sorted(cov.discovery_attempted),
                "discovery_succeeded": sorted(cov.discovery_succeeded),
                "query_families_total": cov.query_families_total,
                "query_families_covered": cov.query_families_covered,
                "query_families_saturated": cov.query_families_saturated,
                "query_families_deferred": cov.query_families_deferred,
                "query_families_never_run": cov.query_families_never_run,
                "backlog_items": cov.backlog_items,
                "backlog_reason": cov.backlog_reason,
                "budgets": cov.budgets,
                "credential_gated": cov.credential_gated,
                "inaccessible": cov.inaccessible,
                "previously_unseen_employers": sorted(cov.previously_unseen_employers),
                "admission_summary": cov.admission_summary,
                "attributions": sorted(set(cov.attributions)),
                "policy_projection_note": cov.policy_projection_note,
            } if cov is not None else None
        ),
        "dedup": inp.dedup or None,
        "events": [e.model_dump(mode="json") for e in inp.events],
        "scorecards": [c.model_dump(mode="json") for c in inp.scorecards],
        "narration_enabled": False,  # M2: deterministic-only path
    }

    _assert_report_language(markdown, report_json, inp)
    return markdown, report_json


def _age_of(job: CanonicalJob, inp: ReportInput, now: datetime) -> str:
    provider = job.source_id.partition(":")[0]
    return age_label(
        provider_published_at=job.provider_published_at,
        provider_updated_at=job.provider_updated_at,
        first_seen_at=job.first_seen_at,
        now=now,
        source_lag_hours=SOURCE_LAG_HOURS.get(provider),
    )


def _below_threshold_count(inp: ReportInput, complete_list, excluded_rows) -> int:
    """Postings that reached scoring but appear in no readable section.

    Named explicitly because an unstated count is a silent discard, and the central workflow forbids
    silently discarding opportunities.
    """
    listed = {card.job_id for card, _job in complete_list}
    listed |= {card.job_id for card, _job in excluded_rows}
    return max(0, len(inp.jobs) - len(listed))


def _fmt(score) -> str:
    return f"{score:.2f}" if score is not None else "UNKNOWN"


def _row(card: DimensionScorecard, job: CanonicalJob, inp: ReportInput) -> str:
    employer = _employer(job, inp.source_labels)
    return (
        f"- {_job_link(job)} — {_md_text(employer)} | {_md_text(_location(job))} | "
        f"fit {card.brett_fit.band.value} {_fmt(card.brett_fit.score)} | "
        f"priority {card.application_priority.band.value} "
        f"{_fmt(card.application_priority.score)} | {_md_text(_why_fit(card))}"
    )


def _profile_version(inp: ReportInput) -> str:
    if inp.scorecards:
        return inp.scorecards[0].scoring_profile_version
    return ScoringProfile().version


def _ratio(inp: ReportInput) -> float:
    if not inp.expected_sources:
        return 0.0
    return round(
        len(set(inp.succeeded_sources) & set(inp.expected_sources))
        / len(set(inp.expected_sources)),
        4,
    )


# --------------------------------------------------------------------------------------------------
# assembly from S3
# --------------------------------------------------------------------------------------------------
def assemble_report_input(s3, bucket: str, run_id: str, dt: str) -> ReportInput:
    """Build ReportInput from S3: RUN_OPEN manifest (expected), SUCCESS sentinels (succeeded),
    the differ's change events, and the current job set. Completeness = manifest-expected vs
    sentinel-succeeded (never wall-clock), per RELIABILITY §5.1."""
    from src.candidate.history import load_history
    from src.candidate.policy import check_divergence, load_projection
    from src.candidate.screening import screen_all
    from src.common import s3layout
    from src.common.dedup import deduplicate

    manifest = _load_json(s3, bucket, s3layout.run_manifest_key(run_id), default=None)
    manifest_present = manifest is not None
    # Real timing, from RUN_OPEN and the previous persisted report. This is the wiring whose absence
    # made every production report show zero fresh arrivals while the renderer tests passed.
    timing = resolve_run_timing(s3, bucket, run_id, dt)
    expected_sources = list(manifest.get("expected_sources", [])) if manifest_present else []
    source_labels = dict(manifest.get("source_labels", {})) if manifest_present else {}
    source_kinds = dict(manifest.get("source_kinds", {})) if manifest_present else {}

    expected_source_set = set(expected_sources)
    succeeded: list[str] = []
    for key in _list_keys(s3, bucket, f"status/run={run_id}/"):
        if key.endswith("/SUCCESS.json"):
            segs = dict(s.split("=", 1) for s in key.split("/") if "=" in s)
            p, b = segs.get("provider"), segs.get("board")
            source_id = f"{p}:{b}" if p and b else ""
            if source_id in expected_source_set:
                succeeded.append(source_id)

    events: list[ChangeEvent] = []
    for sid in expected_sources:
        provider, _, board = sid.partition(":")
        for e in _load_json(s3, bucket, s3layout.events_key(provider, board, dt), default=[]):
            events.append(ChangeEvent.model_validate(e))

    jobs: list[CanonicalJob] = []
    # Score "as of" the moment this round started looking, not the end of its calendar day: at
    # 07:05 the end of day is seventeen hours in the future and every age was computed against it.
    scored_as_of = timing.run_started_at or datetime.fromisoformat(f"{dt}T23:59:59+00:00")
    observations: dict[str, int] = {}
    statuses_by_source: dict[str, list[SnapshotStatus]] = {}
    for sid in expected_sources:
        provider, _, board = sid.partition(":")
        raw_jobs = _load_json(s3, bucket, s3layout.current_jobs_key(provider, board), default=[])
        state = _load_json(s3, bucket, s3layout.current_state_key(provider, board), default={})
        state_jobs = state.get("jobs", {})
        observation_count = max(1, len(state.get("success_count_history", [])))
        observations[sid] = observation_count
        source_events = [event for event in events if event.source_id == sid]
        statuses = [SnapshotStatus.SUCCESS] * observation_count
        if any(e.event_type == ChangeEventType.SOURCE_FETCH_FAILED for e in source_events):
            statuses.append(SnapshotStatus.FETCH_FAILED)
        elif any(e.event_type in (
            ChangeEventType.SOURCE_RESPONSE_PARTIAL, ChangeEventType.SOURCE_SUSPECT
        ) for e in source_events):
            statuses.append(SnapshotStatus.PARTIAL)
        statuses_by_source[sid] = statuses

        for raw_job in raw_jobs:
            job = CanonicalJob.model_validate(raw_job)
            record = state_jobs.get(job.job_id, {})
            if record.get("first_seen_at"):
                job.first_seen_at = _parse_datetime(record["first_seen_at"])
            if record.get("last_seen_at"):
                job.last_seen_at = _parse_datetime(record["last_seen_at"])
            if not job.source_kind and sid in source_kinds:
                job.source_kind = SourceKind(source_kinds[sid])
            jobs.append(job)

    # Cross-source dedup BEFORE scoring, so one posting is scored once and its provenance is intact.
    jobs, dedup_report = deduplicate(jobs)

    scorecards: list[DimensionScorecard] = []
    for job in jobs:
        sid = job.source_id
        source_events = [e for e in events if e.source_id == sid]
        job_events = [e for e in source_events if e.job_id == job.job_id or e.job_id is None]
        scorecards.append(score_job(
            ScoreContext(
                job=job,
                events=job_events,
                recent_snapshot_statuses=statuses_by_source.get(sid, [SnapshotStatus.SUCCESS]),
                num_successful_observations=observations.get(sid, 1),
            ),
            today=scored_as_of,
        ))

    screen_results = screen_all(jobs)

    history = load_history() or None
    history_status: dict = {}
    history_note = None
    if history is None:
        # Visible, not silent. Without the projection every posting reads NEW, which would quietly
        # re-announce work already submitted — exactly the behavior the plan forbids.
        history_note = (
            "application-history projection not found in the deployment package; every posting "
            "below is labelled NEW because no history was available, NOT because none exists"
        )
    else:
        for job in jobs:
            entry = history.lookup(
                employer_name=job.employer_name,
                title=job.title,
                url=job.apply_url or job.posting_url,
            )
            if entry is None:
                continue
            note = entry.conflict_detail if entry.status_conflict else None
            history_status[job.job_id] = (entry.status, note)

    projection = load_projection()
    policy_note = None

    if projection is None:
        policy_note = (
            "no committed policy projection was found; screening ran on the built-in rules and the "
            "projection should be rebuilt"
        )
    else:
        divergence = check_divergence(projection)
        policy_note = (
            f"projection {projection.projection_version} built "
            f"{projection.built_at.date()} — {divergence.summary()}"
        )

    if history_note:
        policy_note = f"{policy_note}; {history_note}" if policy_note else history_note

    coverage = _assemble_coverage(s3, bucket, run_id, jobs, expected_sources, policy_note)

    return ReportInput(
        run_id=run_id,
        dt=dt,
        expected_sources=expected_sources,
        succeeded_sources=sorted(set(succeeded)),
        manifest_present=manifest_present,
        events=events,
        scorecards=scorecards,
        jobs=jobs,
        source_labels=source_labels,
        screen_results=screen_results,
        history_status=history_status,
        coverage=coverage,
        dedup=dedup_report.to_json(),
        run_started_at=timing.run_started_at,
        previous_run_at=timing.previous_run_at,
        previously_reported_ids=(
            timing.previously_reported_ids if timing.previous_run_id else None),
        source_observations=dict(observations),
        timing=timing.to_json(),
    )


def _assemble_coverage(
    s3, bucket: str, run_id: str, jobs, expected_sources, policy_note
) -> CoverageInput:
    """Read the discovery coverage document the discovery stage wrote, if there was one."""
    from src.common import s3layout

    doc = _load_json(s3, bucket, s3layout.discovery_coverage_key(run_id), default=None) or {}
    monitored = {s.partition(":")[2] for s in expected_sources}
    unseen = sorted({
        job.employer_name for job in jobs
        if job.employer_name
        and job.source_kind == SourceKind.DISCOVERY_FEED
        and job.employer_name.lower().replace(" ", "-") not in monitored
    })
    return CoverageInput(
        discovery_attempted=list(doc.get("discovery_attempted", [])),
        discovery_succeeded=list(doc.get("discovery_succeeded", [])),
        query_families_total=doc.get("query_families_total", 0),
        query_families_covered=doc.get("query_families_covered", 0),
        query_families_saturated=list(doc.get("query_families_saturated", [])),
        query_families_deferred=list(doc.get("query_families_deferred", [])),
        query_families_never_run=list(doc.get("query_families_never_run", [])),
        backlog_items=doc.get("backlog_items", 0),
        backlog_reason=doc.get("backlog_reason"),
        budgets=doc.get("budgets", {}),
        credential_gated=list(doc.get("credential_gated", [])),
        inaccessible=list(doc.get("inaccessible", [])),
        attributions=list(doc.get("attributions", [])),
        previously_unseen_employers=unseen,
        admission_summary=doc.get("admission_summary", {}),
        policy_projection_note=policy_note,
    )


def _parse_datetime(value: str | datetime) -> datetime:
    if isinstance(value, datetime):
        return value
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def handler(event, context):
    import os

    import boto3

    from src.common import s3layout

    bucket = os.environ["JPRS_BUCKET"]
    s3 = boto3.client("s3")
    ctx = event.get("runContext") or {}
    run_id = event.get("run_id") or ctx.get("run_id") or datetime.now(timezone.utc).strftime("%Y-%m-%d")
    dt = event.get("dt") or ctx.get("dt") or run_id

    inp = assemble_report_input(s3, bucket, run_id, dt)
    markdown, report_json = render_report(inp)

    s3.put_object(Bucket=bucket, Key=s3layout.report_md_key(dt), Body=markdown.encode(),
                  ContentType="text/markdown")
    s3.put_object(Bucket=bucket, Key=s3layout.report_json_key(dt),
                  Body=json.dumps(report_json, default=str).encode(), ContentType="application/json")

    digest_delivery = "disabled"
    sender = os.environ.get("SES_SENDER", "").strip()
    recipient = os.environ.get("DIGEST_RECIPIENT", "").strip()
    if bool(sender) != bool(recipient):
        raise ValueError("SES_SENDER and DIGEST_RECIPIENT must be configured together")
    if sender and recipient:
        marker_key = s3layout.digest_delivery_key(dt)
        prior_delivery = _load_optional_json(s3, bucket, marker_key)
        if prior_delivery is not None:
            digest_delivery = "already-sent"
        else:
            subject = (
                f"Job radar {dt}: {report_json['new_strong_count']} new, "
                f"{report_json['matching_job_count']} retained "
                f"({report_json['run_health']})"
            )
            message_id = send_digest(
                boto3.client("ses"), sender=sender, recipient=recipient,
                subject=subject, body=markdown,
            )
            s3.put_object(
                Bucket=bucket,
                Key=marker_key,
                Body=json.dumps({
                    "dt": dt,
                    "recipient": recipient,
                    "message_id": message_id,
                    "sent_at": datetime.now(timezone.utc).isoformat(),
                }, separators=(",", ":")).encode(),
                ContentType="application/json",
            )
            digest_delivery = "sent"
    return {
        "run_health": report_json["run_health"], "dt": dt,
        "expected": len(inp.expected_sources), "succeeded": len(inp.succeeded_sources),
        "events": len(inp.events), "matches": report_json["matching_job_count"],
        "new_strong": report_json["new_strong_count"],
        "digest_delivery": digest_delivery,
    }


def send_digest(ses, *, sender: str, recipient: str, subject: str, body: str) -> str:
    """Send the deterministic Markdown report as a plain-text SES email."""
    response = ses.send_email(
        Source=sender,
        Destination={"ToAddresses": [recipient]},
        Message={
            "Subject": {"Data": subject, "Charset": "UTF-8"},
            "Body": {"Text": {"Data": body, "Charset": "UTF-8"}},
        },
    )
    return response["MessageId"]


def _load_json(s3, bucket, key, default="__raise__"):
    import botocore.exceptions

    try:
        obj = s3.get_object(Bucket=bucket, Key=key)
        return json.loads(obj["Body"].read())
    except botocore.exceptions.ClientError as exc:
        code = str(exc.response.get("Error", {}).get("Code", ""))
        if default != "__raise__" and code in ("NoSuchKey", "NoSuchObject", "404", "NotFound"):
            return default
        raise


def _load_optional_json(s3, bucket, key):
    """Load an optional object without treating a permission failure as absence."""
    listing = s3.list_objects_v2(Bucket=bucket, Prefix=key, MaxKeys=1)
    if not any(item.get("Key") == key for item in listing.get("Contents", [])):
        return None
    return _load_json(s3, bucket, key)


def _list_keys(s3, bucket, prefix):
    keys, token = [], None
    while True:
        kw = {"Bucket": bucket, "Prefix": prefix}
        if token:
            kw["ContinuationToken"] = token
        resp = s3.list_objects_v2(**kw)
        keys.extend(o["Key"] for o in resp.get("Contents", []))
        if resp.get("IsTruncated"):
            token = resp.get("NextContinuationToken")
        else:
            break
    return keys
