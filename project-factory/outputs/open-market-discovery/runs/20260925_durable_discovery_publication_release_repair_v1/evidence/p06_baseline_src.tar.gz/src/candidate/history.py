"""Application history — read, never written.

JPRS reads the Career Factory's application packages so it can stop re-announcing work already done.
It has no write path into them, so it *cannot* invent a submission even if a bug tried to.

The five states are not interchangeable, and the default is the weak one:

  SUBMITTED  an explicit line says it was submitted / applied / sent, or the operator confirmed it
  REJECTED   an explicit rejection or closure
  SKIPPED    explicitly considered and passed on, or declined by the operator
  PREPARED   materials exist and nothing says it was submitted  <-- the default
  NEW        no history at all

A folder, a tailored resume PDF, a FORM_ANSWERS.md, or a complete package is PREPARED. The central
workflow says "Prepare the package and leave the status blank", so a blank status means PREPARED and
an upgrade requires a quoted line. Nothing here promotes a status by inference.

Conflicts are PRESERVED. The real corpus contains cases where a package's own note says "NOT
SUBMITTED" while a later day's prose back-references "already applied". That ambiguity is a fact
about the record, so it is recorded as a conflict with both pieces of evidence and surfaced to the
operator — resolving it silently in either direction would be the system inventing a status.

Privacy: the projection keeps employer, role, requisition URL, status, and a pointer to the
evidence. No resume content, no personal circumstances, no contact details.

WHY THERE ARE TWO CONFIDENCE LEVELS
-----------------------------------
The history lives in three successive markdown formats across two months of freeform prose. A regex
scan of it was built, run against the real corpus, and compared to a careful line-by-line reading:
it mis-assigned several statuses in both directions — it called a submitted role skipped because a
later day's prose mentioned the employer in a different context, and it invented employer names out
of folder-name fragments.

That matters asymmetrically. A false SUBMITTED/REJECTED/SKIPPED **hides a live opportunity**, which
is the exact harm this system exists to prevent. A false PREPARED merely files a row in the wrong
report section.

So the scanner is not the authority, and the invariant below is enforced in code:

  reviewed entries  may carry any status, including the suppressing ones. They come from the
                    committed projection, each with a quoted line of evidence.
  parsed entries    are CAPPED at PREPARED. A scan can add a row and can say "materials exist",
                    but it can never conclude on its own that something was submitted, rejected
                    or skipped.

The scanner's real job is drift detection: telling the operator which folders on disk are missing
from the reviewed projection, so a refresh is a visible decision rather than a silent guess.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field

from src.common.models import HistoryStatus
from src.common.normalize import canonical_url, normalize_employer, normalize_title_for_matching

DEFAULT_HISTORY_PATH = "config/application_history.json"
DEFAULT_HISTORY_ROOT = "../Infotropy Book/INBOX/Employment Search"

# Explicit submission evidence. Deliberately narrow: each alternative is a literal claim that the
# application left the building.
_SUBMITTED_RE = re.compile(
    r"\b(status\s*:?\s*\**\s*submitted|submitted (?:on |august|september|july|october|november|"
    r"december|january|\d)|application submitted|submitted\s*\(operator confirmed|"
    r"operator confirmed[^.]{0,40}submit|was submitted|i submitted|confirmed by brett[^.]{0,30}"
    r"submit|rtr sent|profile submitted)\b",
    re.I,
)
_REJECTED_RE = re.compile(
    r"\b(reject(?:ed|ion)|not (?:moving|proceeding) forward|declined by (?:the )?(?:company|employer)|"
    r"closed after (?:the )?final|position (?:was )?filled|no longer under consideration)\b",
    re.I,
)
_SKIPPED_RE = re.compile(
    r"\b(skip(?:ped)?\b|do not apply|declined by brett|not carried into this round|"
    r"removed after preference|pulled\s*/?\s*no longer available|operator decision[^.]{0,20}skip|"
    r"held until|do not resurface)\b",
    re.I,
)
_NOT_SUBMITTED_RE = re.compile(
    r"\b(not (?:yet )?submitted|not submitted|ready for brett|ready to review|"
    r"no application (?:has been|was) (?:represented as )?submitted|submission not yet confirmed|"
    r"ready;? not submitted|leave the status blank|status stays blank|awaiting (?:brett|operator))\b",
    re.I,
)
_STATUS_LINE_RE = re.compile(r"^\s*\**\s*status\s*\**\s*:\s*(.+)$", re.I | re.M)
_MD_LINK_RE = re.compile(r"\[[^\]]*\]\((https?://[^)\s]+)\)")
_BARE_URL_RE = re.compile(r"https?://[^\s)<>\"'\]]+")

# Local-business website-repair outreach shares these folders but is NOT a job application. Feeding
# it to a job deduper would suppress real openings, so it is excluded by marker.
_OUTREACH_MARKERS = re.compile(
    r"\b(outreach|proposal card|first[- ]touch|website repair|cold email|target dossier)\b", re.I
)


class HistoryEntry(BaseModel):
    model_config = ConfigDict(extra="forbid")
    # "reviewed" = a human/agent read the evidence and quoted it; may carry a suppressing status.
    # "parsed"   = produced by the folder scanner; capped at PREPARED by `enforce_confidence_cap`.
    confidence: str = "parsed"
    employer_name: str
    employer_key: str
    role_title: str
    title_key: str
    status: HistoryStatus
    posting_url: str | None = None
    posting_url_key: str | None = None
    folder: str | None = None
    evidence_path: str | None = None
    evidence_quote: str | None = None
    # Preserved ambiguity, never resolved by this code.
    status_conflict: bool = False
    conflict_detail: str | None = None
    observed_at: datetime | None = None


class ApplicationHistory(BaseModel):
    """Privacy-minimized, job-related history projection. Committed so production can read it."""

    model_config = ConfigDict(extra="forbid")
    built_at: datetime
    source_root: str
    entries: list[HistoryEntry] = Field(default_factory=list)
    note: str = (
        "Read-only projection of application history for deduplication only. JPRS never writes "
        "application history. A prepared package is never recorded as submitted without an explicit "
        "quoted line. Conflicting evidence is preserved as a conflict, not resolved. Only entries "
        "marked confidence=reviewed may carry a suppressing status; scanner output is capped at "
        "PREPARED."
    )

    def reviewed_entries(self) -> list[HistoryEntry]:
        return [e for e in self.entries if e.confidence == "reviewed"]

    # ---- lookup -------------------------------------------------------------------------------
    def by_url(self) -> dict[str, HistoryEntry]:
        return {e.posting_url_key: e for e in self.entries if e.posting_url_key}

    def by_employer_title(self) -> dict[tuple[str, str], HistoryEntry]:
        return {(e.employer_key, e.title_key): e for e in self.entries}

    def lookup(self, *, employer_name: str, title: str, url: str | None) -> HistoryEntry | None:
        """Requisition URL wins over employer+title.

        This ordering is load-bearing: the real corpus has one employer with two genuinely different
        requisitions, so matching on employer+title alone would suppress a live opening.
        """
        if url:
            hit = self.by_url().get(canonical_url(url))
            if hit is not None:
                return hit
        return self.by_employer_title().get(
            (normalize_employer(employer_name), normalize_title_for_matching(title))
        )

    def status_for(self, *, employer_name: str, title: str, url: str | None) -> HistoryStatus:
        entry = self.lookup(employer_name=employer_name, title=title, url=url)
        return entry.status if entry else HistoryStatus.NEW


# --------------------------------------------------------------------------------------------------
# Parsing
# --------------------------------------------------------------------------------------------------
def _classify(text: str) -> tuple[HistoryStatus, str | None, bool, str | None]:
    """Classify one blob. Returns (status, quote, conflict, conflict_detail).

    Order matters. A negation ("not submitted", "ready for Brett") beats a bare submission keyword,
    because the corpus is full of packages whose status line literally says both words.
    """
    not_sub = _NOT_SUBMITTED_RE.search(text)
    skipped = _SKIPPED_RE.search(text)
    rejected = _REJECTED_RE.search(text)
    submitted = _SUBMITTED_RE.search(text)

    if rejected:
        return HistoryStatus.REJECTED, _quote(text, rejected), False, None
    if skipped:
        return HistoryStatus.SKIPPED, _quote(text, skipped), False, None
    if submitted and not_sub:
        # Both claims present in the same document. Keep the WEAKER status and flag the conflict.
        return (
            HistoryStatus.PREPARED,
            _quote(text, not_sub),
            True,
            "document contains both a submission claim and a not-submitted claim: "
            f"{_quote(text, submitted)!r} vs {_quote(text, not_sub)!r}",
        )
    if submitted:
        return HistoryStatus.SUBMITTED, _quote(text, submitted), False, None
    return HistoryStatus.PREPARED, _quote(text, not_sub) if not_sub else None, False, None


def _quote(text: str, match: re.Match, width: int = 120) -> str:
    start = max(0, match.start() - 30)
    end = min(len(text), match.end() + width)
    return re.sub(r"\s+", " ", text[start:end]).strip()


def _split_folder_name(name: str) -> tuple[str, str]:
    """`<Employer> - <Role>` / `<Employer> — <Role>` / `<Employer> Application` -> (employer, role)."""
    cleaned = re.sub(r"\s+", " ", name).strip()
    for dash in ("—", " - ", " – "):
        if dash in cleaned:
            employer, _, role = cleaned.partition(dash)
            return employer.strip(), role.strip()
    cleaned = re.sub(
        r"\s+(application|contract|recruiter|interview prep)$", "", cleaned, flags=re.I
    ).strip()
    return cleaned, ""


def _first_url(text: str) -> str | None:
    m = _MD_LINK_RE.search(text) or _BARE_URL_RE.search(text)
    return m.group(1) if (m and m.lastindex) else (m.group(0) if m else None)


def build_history(
    root: str | Path = DEFAULT_HISTORY_ROOT, *, now: datetime | None = None
) -> tuple[ApplicationHistory, list[str]]:
    """Walk the dated application folders and build the projection.

    Local operator command only; opens files read-only and writes nothing under `root`.
    Returns (history, warnings).
    """
    base = Path(root)
    now = now or datetime.now(timezone.utc)
    warnings: list[str] = []
    if not base.is_dir():
        return ApplicationHistory(built_at=now, source_root=str(root)), [
            f"history root not found: {root}"
        ]

    entries: dict[tuple[str, str], HistoryEntry] = {}

    day_dirs = sorted(
        d for d in base.iterdir()
        if d.is_dir() and re.match(r"^\d{4}-\d{2}-\d{2}", d.name)
    )
    for day in day_dirs:
        day_blob = ""
        for index_name in ("DAILY_LOG.md", "START_HERE.md", "APPLICATIONS.md"):
            index_file = day / index_name
            if index_file.is_file():
                try:
                    day_blob += "\n" + index_file.read_text(errors="replace")
                except OSError as exc:  # pragma: no cover - unreadable file
                    warnings.append(f"{index_file}: {exc}")

        for role_dir in sorted(p for p in day.iterdir() if p.is_dir()):
            notes = role_dir / "APPLICATION_NOTES.md"
            blob = ""
            if notes.is_file():
                try:
                    blob = notes.read_text(errors="replace")
                except OSError as exc:  # pragma: no cover
                    warnings.append(f"{notes}: {exc}")
            # A folder with no notes and no application shape is not a job package.
            has_package = notes.is_file() or any(
                (role_dir / f).exists() for f in ("FORM_ANSWERS.md",)
            ) or any(role_dir.glob("*.pdf"))
            if not has_package:
                continue
            if _OUTREACH_MARKERS.search(blob[:2000]) and not notes.is_file():
                continue
            if _OUTREACH_MARKERS.search(role_dir.name):
                continue

            employer, role = _split_folder_name(role_dir.name)
            if not employer:
                continue
            # A recruiter-resume-only folder with no employer is not dedup material.
            if re.match(r"^(generic|new resources)\b", employer, re.I) and not role:
                continue

            status_text = "\n".join(_STATUS_LINE_RE.findall(blob)) or blob[:4000]
            status, quote, conflict, detail = _classify(status_text)

            # Day-level index prose can carry an explicit correction ("X was submitted on ...").
            # It can UPGRADE to submitted/rejected/skipped, and when it disagrees with the folder's
            # own note the disagreement is recorded rather than smoothed away.
            emp_pattern = re.escape(employer.split()[0]) if employer else None
            if emp_pattern and day_blob:
                for line in day_blob.splitlines():
                    if not re.search(emp_pattern, line, re.I):
                        continue
                    line_status, line_quote, _c, _d = _classify(line)
                    if line_status in (
                        HistoryStatus.SUBMITTED, HistoryStatus.REJECTED, HistoryStatus.SKIPPED
                    ) and line_status != status:
                        if status == HistoryStatus.PREPARED and line_status == HistoryStatus.SUBMITTED:
                            conflict = True
                            detail = (
                                f"package note reads not-submitted while the day index states a "
                                f"submission: {line_quote!r}"
                            )
                            # Ambiguous by construction: keep PREPARED, flag it, let the operator
                            # decide. Upgrading here is exactly how a system invents a submission.
                        else:
                            status, quote = line_status, line_quote
                        break

            url = _first_url(blob) or None
            key = (normalize_employer(employer), normalize_title_for_matching(role or employer))
            entry = HistoryEntry(
                employer_name=employer,
                employer_key=normalize_employer(employer),
                role_title=role,
                title_key=normalize_title_for_matching(role or employer),
                status=status,
                posting_url=url,
                posting_url_key=canonical_url(url) if url else None,
                folder=str(role_dir.relative_to(base)),
                evidence_path=str(notes.relative_to(base)) if notes.is_file() else None,
                evidence_quote=(quote or None),
                status_conflict=conflict,
                conflict_detail=detail,
                observed_at=now,
            )
            prior = entries.get(key)
            # A later folder for the same employer+role is a repeat engagement. Keep the STRONGER
            # terminal status (submitted/rejected/skipped outrank prepared) so a re-prepared package
            # cannot erase a recorded submission — that exact case exists in the corpus.
            if prior is None or _rank(entry.status) > _rank(prior.status):
                if prior is not None and prior.posting_url_key and not entry.posting_url_key:
                    entry.posting_url = prior.posting_url
                    entry.posting_url_key = prior.posting_url_key
                entries[key] = entry
            elif prior.status_conflict is False and entry.status_conflict:
                prior.status_conflict = True
                prior.conflict_detail = entry.conflict_detail

    scanned = enforce_confidence_cap(
        sorted(entries.values(), key=lambda e: (e.employer_key, e.title_key))
    )
    return (
        ApplicationHistory(built_at=now, source_root=str(root), entries=scanned),
        warnings,
    )


SUPPRESSING_STATUSES = frozenset({
    HistoryStatus.SUBMITTED, HistoryStatus.REJECTED, HistoryStatus.SKIPPED,
})


def enforce_confidence_cap(entries: list[HistoryEntry]) -> list[HistoryEntry]:
    """Cap scanner-derived entries at PREPARED.

    This is the code-level guarantee behind the module docstring: no amount of regex cleverness lets
    a scan conclude that an application was submitted, rejected or skipped.
    """
    for entry in entries:
        if entry.confidence != "reviewed" and entry.status in SUPPRESSING_STATUSES:
            entry.conflict_detail = (
                f"scanner read this as {entry.status.value} from "
                f"{entry.evidence_quote!r}, but unreviewed scans are capped at PREPARED; "
                "needs operator review before it can suppress a posting"
            )
            entry.status_conflict = True
            entry.status = HistoryStatus.PREPARED
    return entries


_STATUS_RANK = {
    HistoryStatus.NEW: 0,
    HistoryStatus.PREPARED: 1,
    HistoryStatus.SKIPPED: 2,
    HistoryStatus.REJECTED: 3,
    HistoryStatus.SUBMITTED: 4,
}


def _rank(status: HistoryStatus) -> int:
    return _STATUS_RANK.get(status, 0)


def load_history(path: str | Path = DEFAULT_HISTORY_PATH) -> ApplicationHistory | None:
    p = Path(path)
    if not p.is_file():
        return None
    return ApplicationHistory.model_validate(json.loads(p.read_text()))


def save_history(history: ApplicationHistory, path: str | Path = DEFAULT_HISTORY_PATH) -> None:
    Path(path).write_text(json.dumps(history.model_dump(mode="json"), indent=2) + "\n")


def empty_history(now: datetime | None = None) -> ApplicationHistory:
    return ApplicationHistory(
        built_at=now or datetime.now(timezone.utc), source_root="<none>", entries=[]
    )
